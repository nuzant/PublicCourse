// Copyright @2018 Pony AI Inc. All rights reserved.
//
#include <iostream>

int main() {
  std::cout << "Hello World." << std::endl;
  return 0;
}
