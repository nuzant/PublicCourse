hw2 task1
histogram
histdata.cc

hw2 task2
finished with homework3, not posted here

hw2 task3
convert_to_grey.cc hw2 task 3

hw2 task4
lane.cc //data is in directory /PublicCourse/homework2/pony_data, not posted here

