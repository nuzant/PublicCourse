task1 boundary_detection.cc
task2 camera_lidar_fusion_main.cc
task3 perception_obstacles.cc
output homework4/output/{}.perception